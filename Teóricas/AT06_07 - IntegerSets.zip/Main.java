import sets.*;

public class Main {
    public static void main(String[] args) {
        testSimpleSet();
        testOrderedSet();
        testMaxIntSet();
    }

    private static void testSimpleSet() {
        IntSet simpleSet = new SimpleIntSetClass();
        simpleSet.insert(-4);
        simpleSet.insert(6);
        simpleSet.insert(2);
        Iterator iterator = simpleSet.elements();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() +", ");
        }
        System.out.println();
    }

    private static void testOrderedSet() {
        IntSet orderedSet = new OrderedIntSetClass();
        orderedSet.insert(-4);
        orderedSet.insert(6);
        orderedSet.insert(2);
        Iterator iterator = orderedSet.elements();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() +", ");
        }
        System.out.println();
    }

    private static void testMaxIntSet() {
        MaxIntSet maxSet = new MaxIntSetClass();
        maxSet.insert(-4);
        maxSet.insert(6);
        maxSet.insert(2);
        Iterator iterator = maxSet.elements();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() +", ");
        }
        System.out.println("Max = " + maxSet.max());
    }

}