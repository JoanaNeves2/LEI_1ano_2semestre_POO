package sets;

public class OrderedIntSetClass extends AbstractIntSet {

    public OrderedIntSetClass() {
        super();
    }

    private int indexOf(int n) {
        int low = 0;
        int high = counter - 1;
        int mid = -1;
        while (low <= high) {
            mid = (low + high) / 2;
            if (elms[mid] == n) return mid;
            else if (n < elms[mid]) high = mid - 1;
            else low = mid + 1;
        }
        return low;
    }

    public void insert(int x) {
        int pos = indexOf(x);
        if (counter == elms.length)
            resize();
        for (int i = counter; i > pos; i--)
            elms[i] = elms[i - 1];
        elms[pos] = x;
        counter++;
    }

    public void remove(int x) {
        int i = indexOf(x);
        while (i < counter - 1) {
            elms[i] = elms[i + 1];
            i++;
        }
        counter--;
    }

    public boolean isIn(int x) {
        int i = indexOf(x);
        if (counter == i)
            return false;
        return elms[i] == x;
    }
}
