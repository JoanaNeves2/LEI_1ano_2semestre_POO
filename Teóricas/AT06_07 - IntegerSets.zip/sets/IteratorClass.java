package sets;

public class IteratorClass implements Iterator {
    private int[] values;
    private int counter;
    private int current;

    public IteratorClass(int[] elms, int counter) {
        values = new int[counter];
        for (int i = 0; i < counter; i++) {
            values[i] = elms[i];
        }
        this.counter = counter;
        this.current = 0;
    }

    @Override
    public void init() {
        current = 0;
    }

    @Override
    public boolean hasNext() {
        return current < counter;
    }

    @Override
    public int next() {
        return values[current++];
    }
}
