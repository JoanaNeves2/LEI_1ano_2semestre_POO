package sets;

public interface Iterator {
    void init();

    boolean hasNext();

    int next();
}
