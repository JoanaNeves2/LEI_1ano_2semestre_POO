package sets;

abstract class AbstractIntSet implements IntSet {
    /**
     * Dimensão, por omissão, do vector onde guardamos os
     * elementos do conjunto.
     */
    private static final int DEFAULT = 10;

    /**
     * Vector acompanhado onde guardamos os elementos do conjunto
     * de inteiros. Visível nas subclasses.
     */
    protected int[] elms;

    /**
     * Dimensão do conjunto. Protegida, porque todas as
     * implementações concretas de um conjunto vão ter de
     * manter esta variável. Visível nas subclasses.
     */
    protected int counter;

    protected AbstractIntSet() {
        elms = new int[DEFAULT];
        counter = 0;
    }

    protected void resize() {
        int[] tmp = new int[elms.length*2];
        for (int i = 0; i < counter; i++)
            tmp[i] = elms[i];
        elms = tmp;
    }


    public abstract void insert(int x);

    public abstract void remove(int x);

    public abstract boolean isIn(int x);

    public boolean subset(IntSet s) {
        if (s.size() < this.size()) return false;
        for (int i = 0; i < counter; i++)
            if (!s.isIn(elms[i]))
                return false;
        return true;
    }

    public int size() {
        return counter;
    }

    public Iterator elements(){
        return new IteratorClass(elms, counter);
    }
} // Fim da classe abstracta AbstractIntSet
