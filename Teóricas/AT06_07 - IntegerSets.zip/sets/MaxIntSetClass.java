package sets;

public class MaxIntSetClass extends SimpleIntSetClass implements MaxIntSet {
    private int biggest;

    public MaxIntSetClass() {
        super();
        biggest = 0;
    }

    public void insert(int x) {
        if (size() == 0 || x > biggest)
            biggest = x;

        super.insert(x);
    }

    public void remove(int x) {
        super.remove(x);

        if ((size()>0) && (x == biggest)) {
            Iterator it = elements();
            biggest = it.next();
            int tmp;
            while (it.hasNext()) {
                tmp = it.next();
                if (tmp > biggest)
                    biggest = tmp;
            }
        }
    }

    public int max() {
        return biggest;
    }
}
