package sets;

public interface IntSet {
    void insert(int x);

    void remove(int x);

    boolean isIn(int x);

    boolean subset(IntSet s);

    int size();

    Iterator elements();

}
