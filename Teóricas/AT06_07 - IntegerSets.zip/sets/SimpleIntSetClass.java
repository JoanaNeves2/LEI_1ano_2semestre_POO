package sets;

public class SimpleIntSetClass extends AbstractIntSet {
    /**
     * Construtor de <code>SimpleIntSet</code>
     */
    public SimpleIntSetClass() {
        super();
    }

    private int indexOf(int x) {
        int i = 0;
        while (i < counter) {
            if (elms[i]==x)
                return i;
            i++;
        }
        return -1;
    }

    public void insert(int x) {
        if (counter == elms.length) {
            resize();
        }
        elms[counter++] = x;
    }

    public void remove(int x) {
        int index = indexOf(x);
        counter--;
        elms[index] = elms[counter];
    }

    public boolean isIn(int x) {
        return (indexOf(x) != -1);
    }

}
