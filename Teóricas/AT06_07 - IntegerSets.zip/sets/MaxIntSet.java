package sets;

public interface MaxIntSet extends IntSet {
    int max();
}
